import { useState, useCallback } from "react";
import api from "@/lib/api";
import {
  LoginCredentials,
  RegisterCredentials,
  AuthResponse,
  User,
} from "@/types/auth";

export const useAuth = () => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const login = useCallback(async (credentials: LoginCredentials) => {
    try {
      setLoading(true);
      setError(null);
      const { data } = await api.post<AuthResponse>("/token", credentials);
      localStorage.setItem("token", data.access_token);
      await fetchUser();
    } catch {
      setError("Invalid credentials");
    } finally {
      setLoading(false);
    }
  }, []);

  const register = useCallback(
    async (credentials: RegisterCredentials) => {
      try {
        setLoading(true);
        setError(null);
        await api.post("/users/", {
          email: credentials.email,
          password: credentials.password,
        });
        await login({
          email: credentials.email,
          password: credentials.password,
        });
      } catch {
        setError("Registration failed");
      } finally {
        setLoading(false);
      }
    },
    [login]
  );

  const fetchUser = useCallback(async () => {
    try {
      setLoading(true);
      const { data } = await api.get<User>("/users/me");
      setUser(data);
    } catch {
      setUser(null);
    } finally {
      setLoading(false);
    }
  }, []);

  const logout = useCallback(() => {
    localStorage.removeItem("token");
    setUser(null);
  }, []);

  return {
    user,
    loading,
    error,
    login,
    register,
    logout,
    fetchUser,
  };
};
