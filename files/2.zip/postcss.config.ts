export default {
    plugins: {
        tailwindcss: {},
        autoprefixer: {}
    }
};export default {
    plugins: {
        tailwindcss: {},
        autoprefixer: {}
    }
};