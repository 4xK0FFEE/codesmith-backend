import { Button } from "@/components/ui/button";

function App() {
    return (
        <div className='flex items-center justify-center h-screen'>
            <Button>Click me</Button>
        </div>
    );
}

export default App;import { Button } from "@/components/ui/button";

function App() {
    return (
        <div className='flex items-center justify-center h-screen'>
            <Button>Click me</Button>
        </div>
    );
}

export default App;